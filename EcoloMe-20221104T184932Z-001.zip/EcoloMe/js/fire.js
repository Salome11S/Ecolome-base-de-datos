// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAr19IXIz4_dtCbNs5NSysAxSxRoBADBTM",
  authDomain: "ecolome-6f7f0.firebaseapp.com",
  projectId: "ecolome-6f7f0",
  storageBucket: "ecolome-6f7f0.appspot.com",
  messagingSenderId: "637743037605",
  appId: "1:637743037605:web:d67a860b3519c78452214c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);